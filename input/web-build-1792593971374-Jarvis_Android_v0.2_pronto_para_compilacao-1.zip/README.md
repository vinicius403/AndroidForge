# JARVIS Android 0.2 — build-ready

Este projeto é uma base Android nativa para o JARVIS 0.2.

## O que já está implementado
- Interface nativa simples.
- Reconhecimento de voz em português (pt-BR) acionado pelo botão.
- Respostas faladas com Text-to-Speech.
- Estilo de voz configurado para uma fala um pouco mais grave/lenta.
- Abertura do YouTube, Spotify e WhatsApp.
- Pesquisa por voz no Google, YouTube e Spotify.
- Comandos de mídia: pausar, continuar, próxima, anterior, avançar 5/30 s e voltar 5/30 s.
- Acesso a sessões de mídia por meio de Notification Listener Service, quando o usuário conceder esse acesso.

## Limitações atuais
- A palavra de ativação contínua “JARVIS” ainda não está implementada.
- O controle de mídia depende de o usuário habilitar o acesso de notificações para o JARVIS e de o aplicativo de música expor uma MediaSession.
- A voz com sotaque britânico depende da voz TTS instalada no aparelho; o aplicativo apenas configura idioma, velocidade e tom.

## Compilação
Requer um ambiente Android com:
- Android SDK com API 35.
- JDK compatível com Android Gradle Plugin 8.7.3.
- Gradle compatível (8.9 é a opção recomendada para AGP 8.7.x).

Com o projeto aberto no ambiente de build:
`gradle :app:assembleDebug`

O APK esperado ficará em:
`app/build/outputs/apk/debug/app-debug.apk`

Importante: este ZIP contém o código-fonte e a configuração do projeto; ele não é o APK já compilado.
