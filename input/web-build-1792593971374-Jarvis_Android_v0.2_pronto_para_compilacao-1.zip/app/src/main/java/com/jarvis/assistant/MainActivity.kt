package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.content.ComponentName
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var button: Button
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var mediaController: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this, this)
        requestAudioPermission()
        findActiveMediaSession()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(0xFF090B10.toInt())
        }
        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(0xFFEAF8FF.toInt())
        }
        status = TextView(this).apply {
            text = "Pronto para ajudar, senhor."
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
            setTextColor(0xFFBFDFFF.toInt())
        }
        button = Button(this).apply {
            text = "🎙 Falar com JARVIS"
            textSize = 18f
            setOnClickListener { listen() }
        }
        root.addView(title)
        root.addView(status)
        root.addView(button)
        setContentView(root)
    }

    private fun requestAudioPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speak("Senhor, preciso da permissão do microfone.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {
                    status.text = "Estou ouvindo, senhor..."
                    button.text = "🔴 Ouvindo..."
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { button.text = "🎙 Falar com JARVIS" }
                override fun onError(e: Int) {
                    status.text = "Não consegui ouvir. Tente novamente, senhor."
                    button.text = "🎙 Falar com JARVIS"
                }
                override fun onResults(r: Bundle?) {
                    val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text != null) handleCommand(text)
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(original: String) {
        findActiveMediaSession()
        val text = original.lowercase(Locale("pt", "BR"))
        status.text = "Você disse: $original"

        when {
            text.contains("pausa") || text.contains("pause") -> {
                speak("Sim, senhor. Pausando a música.")
                mediaController?.transportControls?.pause()
            }
            text.contains("continue a música") || text.contains("retome a música") -> {
                speak("Sim, senhor. Retomando a música.")
                mediaController?.transportControls?.play()
            }
            text.contains("próxima música") || text.contains("proxima música") -> {
                speak("Sim, senhor. Próxima faixa.")
                mediaController?.transportControls?.skipToNext()
            }
            text.contains("música anterior") || text.contains("musica anterior") -> {
                speak("Sim, senhor. Voltando à faixa anterior.")
                mediaController?.transportControls?.skipToPrevious()
            }
            text.contains("avance 5 segundos") -> seekBy(5000L)
            text.contains("avance 30 segundos") -> seekBy(30000L)
            text.contains("volte 5 segundos") -> seekBy(-5000L)
            text.contains("volte 30 segundos") -> seekBy(-30000L)
            text.contains("abra o youtube") || text.contains("abrir o youtube") -> {
                speak("Sim, senhor. Abrindo o YouTube.")
                openUrl("https://www.youtube.com")
            }
            text.contains("abra o spotify") || text.contains("abrir o spotify") -> {
                speak("Sim, senhor. Abrindo o Spotify.")
                openUrl("https://open.spotify.com")
            }
            text.contains("abra o whatsapp") || text.contains("abrir o whatsapp") -> {
                speak("Sim, senhor. Abrindo o WhatsApp.")
                openPackage("com.whatsapp")
            }
            text.contains("youtube") && (text.contains("pesquis") || text.contains("procure")) -> {
                val q = extractQuery(original)
                speak("Sim, senhor. Pesquisando no YouTube.")
                openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q))
            }
            text.contains("spotify") && (text.contains("pesquis") || text.contains("procure")) -> {
                val q = extractQuery(original)
                speak("Sim, senhor. Pesquisando no Spotify.")
                openUrl("https://open.spotify.com/search/" + Uri.encode(q))
            }
            text.contains("pesquise") || text.contains("pesquisar") || text.contains("procure") -> {
                val q = extractQuery(original)
                speak("Sim, senhor. Abrindo a pesquisa.")
                openUrl("https://www.google.com/search?q=" + Uri.encode(q))
            }
            else -> speak("Entendido, senhor. Essa função ainda está sendo construída.")
        }
    }

    private fun extractQuery(text: String): String {
        val lower = text.lowercase(Locale("pt", "BR"))
        val keys = listOf("pesquise", "pesquisa", "pesquisar", "procure", "buscar", "busque")
        for (key in keys) {
            val i = lower.indexOf(key)
            if (i >= 0) {
                val q = text.substring(i + key.length).trim()
                if (q.isNotBlank()) return q.removePrefix("por ").trim()
            }
        }
        return text
    }

    private fun seekBy(delta: Long) {
        val c = mediaController
        if (c == null) {
            speak("Senhor, não encontrei uma sessão de mídia controlável.")
            return
        }
        val current = c.playbackState?.position ?: 0L
        val duration = c.metadata?.getLong("android.media.metadata.DURATION") ?: Long.MAX_VALUE
        c.transportControls.seekTo(max(0L, min(current + delta, duration)))
        speak("Sim, senhor.")
    }

    private fun findActiveMediaSession() {
        try {
            val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
            if (!enabled.contains(packageName)) return
            val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            mediaController = manager.getActiveSessions(ComponentName(this, JarvisNotificationListenerService::class.java)).firstOrNull()
        } catch (_: Exception) {
            mediaController = null
        }
    }

    private fun openPackage(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else speak("Senhor, esse aplicativo não parece estar instalado.")
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            tts.language = Locale("pt", "BR")
            tts.setSpeechRate(0.93f)
            tts.setPitch(0.88f)
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
