package com.jarvis.assistant

import android.service.notification.NotificationListenerService

/**
 * Gives JARVIS access to active media sessions after the user enables
 * notification-listener access in Android Settings.
 */
class JarvisNotificationListenerService : NotificationListenerService()
